import screeninfo.enumerators.cygwin
import screeninfo.enumerators.drm
import screeninfo.enumerators.osx
import screeninfo.enumerators.windows
import screeninfo.enumerators.xinerama
import screeninfo.enumerators.xrandr
